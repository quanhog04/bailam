﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thucHanh5_11
{
    internal class Customer
    {
        public int ID {  get; set; } 
        public string Name { get; set; }
        public string SDT { get; set; }
        public string Diachi { get; set; }
    }
}
